﻿Imports System.ComponentModel
Imports System.Runtime.InteropServices                  'For stopping strem



Public Class Form1

    Dim time As TimeSpan            'global variable for download time
    Public StreamName As String = ""

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'disable form size change
        Me.FormBorderStyle = FormBorderStyle.FixedSingle
        'start position
        Me.StartPosition = FormStartPosition.Manual
        Me.Location = New Point((Screen.PrimaryScreen.Bounds.Size.Width / 2) - (Me.Size.Width / 2), (Screen.PrimaryScreen.Bounds.Size.Height / 2) - (Me.Size.Height / 2))

        'create design, set positions and sizes
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.Width = 700
        Me.Height = 360
        Me.BackColor = Color.FromArgb(52, 73, 94)
        Me.MaximizeBox = False

        Panel1.Height = 40
        Panel1.Location = New Point(0, 0)
        Panel1.Width = Me.ClientSize.Width
        Panel1.BackColor = Color.FromArgb(235, 77, 75)

        Button1.ForeColor = Color.Black
        Button1.FlatAppearance.BorderColor = Color.FromArgb(52, 73, 94)
        Button1.BackColor = System.Drawing.SystemColors.Control
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Height = 30
        Button1.Top = Panel1.Height / 2 - Button1.Height / 2
        Button1.Width = Button1.Height
        Button1.Left = Me.ClientSize.Width - 12 - Button1.Width
        Button1.Font = New Font(New FontFamily("Arial"), 12, FontStyle.Bold)
        Button1.TextAlign = ContentAlignment.BottomCenter
        Button1.TabIndex = 0
        Button1.Text = ""

        Button3.ForeColor = Color.Black
        Button3.FlatAppearance.BorderColor = Color.FromArgb(52, 73, 94)
        Button3.BackColor = Color.FromArgb(255, 234, 167)
        Button3.FlatStyle = FlatStyle.Flat
        Button3.Height = 30
        Button3.Top = Panel1.Height / 2 - Button3.Height / 2
        Button3.Width = Button3.Height
        Button3.Left = 12
        Button3.Font = New Font(New FontFamily("Arial"), 12, FontStyle.Bold)
        Button3.TextAlign = ContentAlignment.BottomCenter
        Button3.TabIndex = 0
        Button3.Text = ""

        TextBox1.BorderStyle = BorderStyle.FixedSingle
        TextBox1.Text = "YouTube Stream Link..."
        TextBox1.ForeColor = Color.FromArgb(127, 140, 141)
        TextBox1.Font = New Font(New FontFamily("Arial"), 12, FontStyle.Regular)
        TextBox1.Location = New Point(12 * 2 + Button3.Width, (Panel1.Height / 2 - TextBox1.Height / 2) + 1)
        TextBox1.Width = Me.ClientSize.Width - Button3.Left * 4 - Button1.Width * 2
        TextBox1.BringToFront()

        TextBox2.BorderStyle = BorderStyle.FixedSingle
        TextBox2.BackColor = Color.FromArgb(255, 234, 167)
        TextBox2.ForeColor = Color.FromArgb(127, 140, 141)
        TextBox2.Font = New Font(New FontFamily("Arial"), 12, FontStyle.Regular)
        TextBox2.Location = TextBox1.Location
        TextBox2.Width = TextBox1.Width
        TextBox2.ReadOnly = True

        Button2.ForeColor = Color.FromArgb(55, 55, 55)
        Button2.FlatAppearance.BorderColor = Color.FromArgb(52, 73, 94)
        Button2.BackColor = Color.FromArgb(46, 204, 113)
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Width = 86
        Button2.Height = Button2.Width
        Button2.Left = Me.ClientSize.Width / 2 - Button2.Width / 2
        Button2.Font = New Font(New FontFamily("Arial"), 16, FontStyle.Bold)
        Button2.Text = "REC"

        PictureBox1.Location = New Point(12, Panel1.Height + 12)
        PictureBox1.BorderStyle = BorderStyle.None
        PictureBox1.Width = Me.ClientSize.Width / 2 - PictureBox1.Left * 2 - Button2.Width / 2
        PictureBox1.Height = PictureBox1.Width / 1.77
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage

        Button2.Top = PictureBox1.Top + PictureBox1.Height

        TextBox3.Text = "   "
        TextBox3.BorderStyle = BorderStyle.None
        TextBox3.BackColor = Color.FromArgb(52, 73, 94)
        TextBox3.ForeColor = Color.White
        TextBox3.Font = New Font(New FontFamily("Arial"), 12, FontStyle.Regular)
        TextBox3.Location = New Point(Me.ClientSize.Width / 2 - Button2.Width / 2, PictureBox1.Top)
        TextBox3.Width = Button1.Left + Button1.Width - TextBox3.Left
        TextBox3.ReadOnly = True

        RichTextBox1.BorderStyle = BorderStyle.None
        RichTextBox1.BackColor = Color.FromArgb(52, 73, 94)
        RichTextBox1.ForeColor = Color.White
        RichTextBox1.Location = New Point(Me.ClientSize.Width / 2 - Button2.Width / 2, PictureBox1.Top + TextBox2.Height + TextBox1.Top)
        RichTextBox1.Width = TextBox3.Width
        RichTextBox1.Height = PictureBox1.Height - TextBox2.Height - PictureBox1.Left
        RichTextBox1.ReadOnly = True

        Panel2.Left = 0
        Panel2.Height = 60
        Panel2.Width = Me.ClientSize.Width
        Panel2.Top = Button2.Top + (Button2.Height / 2 - Panel2.Height / 2)
        Panel2.BackColor = Color.FromArgb(46, 204, 113)

        Label1.Text = "Stream quality:"
        Label1.Left = PictureBox1.Left
        Label1.Top = Button2.Top + (Button2.Height / 2 - (Label2.Height / 2) - 4)
        Label1.Font = New Font(New FontFamily("Arial"), 12, FontStyle.Regular)
        Label1.BackColor = Color.FromArgb(46, 204, 113)
        Label1.ForeColor = Color.FromArgb(55, 55, 55)

        ComboBox1.Left = Label1.Left + Label1.Width
        ComboBox1.Top = Label1.Top
        ComboBox1.Width = PictureBox1.Width - Label1.Width

        ComboBox1.Items.Clear()
        ComboBox1.Items.Add("144")
        ComboBox1.Items.Add("240")
        ComboBox1.Items.Add("360")
        ComboBox1.Items.Add("480")
        ComboBox1.Items.Add("720")
        ComboBox1.Items.Add("1080")
        ComboBox1.Items.Add("1440")
        ComboBox1.Items.Add("2160")

        Label2.Left = Me.ClientSize.Width / 2 + Button2.Width / 2 + Button3.Left
        Label2.Top = Panel2.Top + Panel2.Height + Button3.Left
        Label2.Font = New Font(New FontFamily("Arial"), 9, FontStyle.Regular)
        Label2.BackColor = Color.FromArgb(52, 73, 94)
        Label2.ForeColor = Color.White
        Label2.Text = ""

        Label3.Top = Label2.Top
        Label3.Font = New Font(New FontFamily("Arial"), 9, FontStyle.Regular)
        Label3.Text = "00:00:00"
        'Label3.Left = Button2.Left - Label3.Width - Button3.Left
        Label3.Left = Me.ClientSize.Width / 2 - (Label2.Left - Me.ClientSize.Width / 2) - Label3.Width
        Label3.BackColor = Color.FromArgb(52, 73, 94)
        Label3.ForeColor = Color.White
        Label3.Text = ""

        Label4.Text = "Start:"
        Label4.Left = Button2.Left + Button2.Width + Button3.Left
        Label4.Top = Panel2.Top + (Panel2.Height - Label4.Height * 2) / 5
        Label4.Font = New Font(New FontFamily("Arial"), 12, FontStyle.Regular)
        Label4.BackColor = Color.FromArgb(46, 204, 113)
        Label4.ForeColor = Color.FromArgb(55, 55, 55)

        DateTimePicker1.Top = Label4.Top
        DateTimePicker1.Left = Label4.Left + Label4.Width
        DateTimePicker1.Width = 50

        Label5.Text = "End: "
        Label5.Left = Label4.Left
        Label5.Top = Label4.Top + Label4.Height + (Label4.Top - Panel2.Top)
        Label5.Font = New Font(New FontFamily("Arial"), 12, FontStyle.Regular)
        Label5.BackColor = Color.FromArgb(46, 204, 113)
        Label5.ForeColor = Color.FromArgb(55, 55, 55)

        DateTimePicker2.Top = Label5.Top
        DateTimePicker2.Left = DateTimePicker1.Left
        DateTimePicker2.Width = DateTimePicker1.Width

        'dateTimePicker settings
        DateTimePicker1.Format = DateTimePickerFormat.Time    'remove years, months, days and leave only time
        DateTimePicker2.Format = DateTimePickerFormat.Time
        DateTimePicker1.CustomFormat = "HH:mm"                'show only hours and minutes
        DateTimePicker1.Format = DateTimePickerFormat.Custom
        DateTimePicker2.CustomFormat = "HH:mm"
        DateTimePicker2.Format = DateTimePickerFormat.Custom
        DateTimePicker1.ShowUpDown = True                     'disable calendar and show updown menu
        DateTimePicker2.ShowUpDown = True
        DateTimePicker1.Value = Date.FromOADate(0)            'set timer to zero
        DateTimePicker2.Value = Date.FromOADate(0)

        'timer for file size check
        Timer1.Enabled = True
        Timer1.Interval = 200

        'timer for download time
        time = New TimeSpan(0, 0, 0)                        'define HH:MM:SS
        Timer2.Enabled = True
        Timer2.Interval = 1000

        Button2.BringToFront()                              'bring button to most top
        '----------------------- create options file if not exist --------------
        If Not System.IO.File.Exists(Application.StartupPath & "\YSRec_options.ini") Then                       'if options file not exist
            System.IO.File.Create(Application.StartupPath & "\YSRec_options.ini").Dispose()                     'create options file
            Dim createText() As String = {"", ""}                                                                     ' write empty lines in options file
            System.IO.File.WriteAllLines(Application.StartupPath & "\YSRec_options.ini", createText)
        End If

        '---------------------- save new options ------------------------------
        Dim Lines() As String = System.IO.File.ReadAllLines(Application.StartupPath & "\YSRec_options.ini")
        TextBox2.Text = (Application.StartupPath & "\").Replace("\\", "\")
        If Lines(0) = "" Then Lines(0) = TextBox2.Text
        If Lines(0) <> "" Then TextBox2.Text = Lines(0)

        If Lines(1) = "" Then Lines(1) = 4
        If Lines(1) <> "" Then ComboBox1.SelectedIndex = Lines(1)

        System.IO.File.WriteAllLines(Application.StartupPath & "\YSRec_options.ini", Lines)
    End Sub

    Private Sub TextBox1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox1.Click
        If TextBox1.Text = "YouTube Stream Link..." Then
            TextBox1.Text = ""
            TextBox1.ForeColor = Color.FromArgb(55, 55, 55)
        End If
    End Sub

    Private Sub TextBox1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox1.DoubleClick
        TextBox1.Text = ""
    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox1.ForeColor = Color.FromArgb(RGB(55, 55, 55))
        TextBox1.Text = Clipboard.GetText
        'Me.TextBox1.Paste()
    End Sub

    Private Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click

        If ComboBox1.SelectedItem = 0 Or TextBox1.Text = "" Or TextBox1.Text = "YouTube Stream Link..." Then
            Label2.Text = "Stream link not found"
            Exit Sub
        End If

        '---------------< start record >---------------
        If Button2.Text = "REC" Then

            '####################### Thread start
            System.Windows.Forms.Control.CheckForIllegalCrossThreadCalls = False
            Dim Thread As System.Threading.Thread = New System.Threading.Thread(
                Sub(t)

                    Button2.Text = "STOP"
                    Button2.BackColor = Color.FromArgb(235, 77, 75)
                    Button2.ForeColor = Color.FromArgb(255, 255, 255)
                    Button2.Refresh()

                    '##############################################< get thumbnail , convert to *.jpg >##############################################
                    Label2.Text = "Thumbnail download running..."
                    Label2.Refresh()

                    'send comand to cmd, try to download thumbnail and convert it to *.jpg
                    Dim Process As New Process()
                    Dim StartInfo As New ProcessStartInfo("cmd.exe", " /c " & Application.StartupPath() & "\yt-dlp.exe --skip-download --write-thumbnail --convert-thumbnails jpg " & TextBox1.Text & " && exit")
                    StartInfo.UseShellExecute = False
                    StartInfo.RedirectStandardOutput = True
                    Process.StartInfo = StartInfo
                    Process.StartInfo.CreateNoWindow = True   'hide cmd window
                    Process.Start()

                    'read the cmd feedback line by line
                    Dim Output As String
                    Using StreamReader As System.IO.StreamReader = Process.StandardOutput
                        Output = StreamReader.ReadToEnd()
                    End Using

                    'save all lines/feedback to variable
                    Dim Lines() As String = Output.Split(CChar(vbNewLine))
                    Dim StringTemp As String = Lines(0)

                    'find a youtube part link 
                    Dim YouTubePartLink As String = TextBox1.Text
                    YouTubePartLink = YouTubePartLink.Substring(YouTubePartLink.IndexOf("=") + 1)

                    'try to insert thumbnail in picturebox
                    If StringTemp.Contains(".webp") Then
                        For Each Thumbnails As String In My.Computer.FileSystem.GetFiles(Application.StartupPath(), FileIO.SearchOption.SearchTopLevelOnly, "*.jpg")
                            If Thumbnails.Contains(YouTubePartLink) Then

                                If Not System.IO.Directory.Exists(Application.StartupPath() & "\YSRecThumbnails\") Then
                                    System.IO.Directory.CreateDirectory(Application.StartupPath() & "\YSRecThumbnails\")
                                End If

                                System.IO.File.Move(Thumbnails, Application.StartupPath() & "\YSRecThumbnails\" & System.IO.Path.GetFileName(Thumbnails))

                                PictureBox1.Image = Image.FromFile(Application.StartupPath() & "\YSRecThumbnails\" & System.IO.Path.GetFileName(Thumbnails))
                                PictureBox1.Refresh()
                            End If
                        Next
                    End If

                    '##############################################< get stream title >##############################################

                    Label2.Text = "Title download running..."
                    Label2.Refresh()

                    'send comand to cmd, try to download title
                    Dim Process2 As New Process()
                    Dim StartInfo2 As New ProcessStartInfo("cmd.exe", " /c " & Application.StartupPath() & "\yt-dlp.exe --skip-download --get-title --no-warnings " & TextBox1.Text & " && exit")
                    StartInfo2.UseShellExecute = False
                    StartInfo2.RedirectStandardOutput = True
                    Process2.StartInfo = StartInfo2
                    Process2.StartInfo.CreateNoWindow = True   'hide cmd window
                    Process2.Start()

                    'read the cmd feedback line by line
                    Dim Output2 As String
                    Using StreamReader2 As System.IO.StreamReader = Process2.StandardOutput
                        Output2 = StreamReader2.ReadToEnd()
                    End Using

                    'save all lines/feedback and put in TextBox
                    Dim Lines2() As String = Output2.Split(CChar(vbNewLine))
                    TextBox3.Text = Lines2(0)
                    TextBox3.Text = TextBox3.Text.Substring(0, TextBox3.TextLength - 18)

                    'create textbox that fill the textbox. importabnt for sliding animation
                    Dim TextSize As Size = TextRenderer.MeasureText(TextBox3.Text, Me.Font)   'get size for youtube title(text)

                    Do While TextSize.Width.ToString < TextBox3.Width * 0.7
                        TextBox3.Text = TextBox3.Text & " "
                        TextSize = TextRenderer.MeasureText(TextBox3.Text, Me.Font)
                    Loop

                    TextBox3.Refresh()

                    '##############################################< get stream description >##############################################

                    Label2.Text = "Description download running..."
                    Label2.Refresh()

                    'send comand to cmd, try to download describtion
                    Dim Process3 As New Process()
                    Dim StartInfo3 As New ProcessStartInfo("cmd.exe", " /c " & Application.StartupPath() & "\yt-dlp.exe --skip-download --get-description --no-warnings " & TextBox1.Text & " && exit")
                    StartInfo3.UseShellExecute = False
                    StartInfo3.RedirectStandardOutput = True
                    Process3.StartInfo = StartInfo3
                    Process3.StartInfo.CreateNoWindow = True   'hide cmd window
                    Process3.Start()

                    'read the cmd feedback line by line
                    Dim Output3 As String
                    Using StreamReader3 As System.IO.StreamReader = Process3.StandardOutput
                        Output3 = StreamReader3.ReadToEnd()
                    End Using

                    'save all lines/feedback and put in RichTextBox
                    Dim Lines3() As String = Output3.Split(CChar(vbNewLine))
                    RichTextBox1.Text = Lines3(0)
                    RichTextBox1.BackColor = Color.FromArgb(96, 107, 120)
                    RichTextBox1.Refresh()

                    '##############################################< get stream link >##############################################

                    Label2.Text = "Get stream link..."
                    Label2.Refresh()

                    'send comand to cmd, try to download stream link
                    Dim Process4 As New Process()
                    Dim StartInfo4 As New ProcessStartInfo("cmd.exe", " /c " & Application.StartupPath() & "\yt-dlp.exe -f (" & Chr(34) & "bestvideo[height<=" & ComboBox1.SelectedItem & "]+bestaudio/best[height<=" & ComboBox1.SelectedItem & "]" & Chr(34) & ") -g " & TextBox1.Text & " && exit")
                    StartInfo4.UseShellExecute = False
                    StartInfo4.RedirectStandardOutput = True
                    Process4.StartInfo = StartInfo4
                    Process4.StartInfo.CreateNoWindow = True   'hide cmd window
                    Process4.Start()

                    'read the cmd feedback line by line
                    Dim Output4 As String
                    Using StreamReader4 As System.IO.StreamReader = Process4.StandardOutput
                        Output4 = StreamReader4.ReadToEnd()
                    End Using

                    'save all lines/feedback to variable
                    Dim Lines4() As String = Output4.Split(CChar(vbNewLine))

                    '##############################################< start stream recording >##############################################

                    Label2.Text = "Stream download..."
                    Label2.Refresh()

                    StreamName = (DateTime.Now.ToString("yyyy/MM/dd") & "_" & DateTime.Now.ToString("HH:mm:ss") & "_Stream").Replace(":", ".").Replace("/", ".")

                    'send comand to cmd, try to download stream
                    Dim Process5 As New Process()
                    Dim test As String = (Application.StartupPath() & "\ffmpeg.exe -i " & Lines4(0) & " -c copy -bsf:a aac_adtstoasc " & TextBox2.Text & StreamName & ".mp4 && exit").Replace(vbCr, "").Replace(vbLf, "")
                    Dim StartInfo5 As New ProcessStartInfo("cmd.exe", " /c " & test)
                    StartInfo5.UseShellExecute = False
                    StartInfo5.RedirectStandardOutput = True
                    Process5.StartInfo = StartInfo5
                    Process5.StartInfo.CreateNoWindow = False   'hide cmd window
                    Process5.Start()

                    'check if cmd window was opened and Handle was created
                    Dim CMD_Window_Handle As Integer
                    Do While (CMD_Window_Handle_Save = 0)                               'if no window was created/opened , handle is 0. If Handle>0 -> cmd window can be hide
                        Dim processRunning As Process() = Process.GetProcesses()
                        For Each pr As Process In processRunning
                            If pr.ProcessName = "cmd" Then
                                CMD_Window_Handle = pr.MainWindowHandle.ToInt32()
                                CMD_Window_Handle_Save = CMD_Window_Handle
                            End If
                        Next
                    Loop

                    ShowWindow(CMD_Window_Handle, 0)                                     'hide cmd window

                    '####################### Thread end
                End Sub) With {.IsBackground = True}
            Thread.Start()

        Else

            '##############################################< stop stream recording  >##############################################
            DateTimePicker1.Value = Date.FromOADate(0)            'set timer to zero
            DateTimePicker2.Value = Date.FromOADate(0)
            DateTimePicker1.Value = Date.FromOADate(0)            'set timer to zero
            DateTimePicker2.Value = Date.FromOADate(0)

            TextBox3.Text = "   "
            RichTextBox1.Text = ""
            RichTextBox1.BackColor = Color.FromArgb(52, 73, 94)

            Try
                ShowWindow(CMD_Window_Handle_Save, 5)                                'show cmd window
                AppActivate("C:\WINDOWS\SYSTEM32\cmd.exe")                           'bring cmd window to front
                SendKeys.Send("^{C}")                                                'send CTL+C to cmd to stop ffmpeg recording and close cmd
                ShowWindow(CMD_Window_Handle_Save, 0)                                'hide cmd window
            Catch ex As Exception
            End Try

            CMD_Window_Handle_Save = 0                                               'set value to 0 to be ready for hide the next cmd window

            Button2.Text = "REC"
            Button2.BackColor = Color.FromArgb(46, 204, 113)
            Button2.ForeColor = Color.FromArgb(55, 55, 55)

            Call DeleteThumbnail()  'delete all thumbnails in program folder

            Label2.Text = "Stream recording finished!"
            Label2.Refresh()

        End If

    End Sub

    Private Sub DeleteThumbnail()
        'delete all thumbnails from program folder
        Try
            PictureBox1.Image.Dispose()
            'PictureBox1.BackgroundImage = Nothing

            For Each Thumbnails As String In My.Computer.FileSystem.GetFiles(Application.StartupPath() & "\YSRecThumbnails\", FileIO.SearchOption.SearchTopLevelOnly, "*.jpg")
                System.IO.File.Delete(Thumbnails)
            Next

            PictureBox1.Image = PictureBox1.ErrorImage
        Catch ex As Exception
        End Try
    End Sub

    Public CMD_Window_Handle_Save As String = 0                                      'public/global variable to save cmd Handle number

    'dll for cmd show/hide
    <DllImport("user32.dll")>
    Private Shared Function ShowWindow(ByVal hWnd As IntPtr, ByVal nCmdShow As Integer) As Boolean
    End Function

    '#############################################################################################################


    Private Sub Timer1_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles Timer1.Tick

        '##############################################< sliding animation of title in TextBox >##############################################
        Dim temp As String = TextBox3.Text.Substring(0, 1)
        TextBox3.Text = TextBox3.Text.Substring(1)
        TextBox3.Text = TextBox3.Text & temp

        '##############################################< check stream file size >##############################################
        Try
            If Label2.Text.Contains("Stream download...") Then
                Dim StreamSize As Integer = My.Computer.FileSystem.GetFileInfo(TextBox2.Text & StreamName & ".mp4").Length

                Dim KB As Integer = 1024
                Dim MB As Integer = KB * 1024
                Dim GB As Integer = MB * 1024

                If StreamSize < KB Then
                    Dim NewSize As Integer = StreamSize
                    Label2.Text = "Stream download... | Stream file size: " & NewSize & " Bytes".ToString()
                ElseIf StreamSize < MB Then
                    Dim NewSize As Integer = StreamSize / KB
                    Label2.Text = "Stream download... | Stream file size: " & NewSize & " KB".ToString()
                ElseIf StreamSize < GB Then
                    Dim NewSize As Integer = StreamSize / MB
                    Label2.Text = "Stream download... | Stream file size: " & NewSize & " MB".ToString()
                ElseIf StreamSize >= GB Then
                    Dim NewSize As Integer = StreamSize / GB
                    Label2.Text = "Stream download... | Stream file size: " & NewSize & " GB".ToString()
                Else
                End If

            End If
        Catch ex As Exception
        End Try

    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        'timer to show downloading time
        If Label2.Text.Contains("Stream download...") Then
            time += New TimeSpan(0, 0, 1)
            Label3.Text = time.ToString.Substring(0)
        Else
            Label3.Text = ""
        End If

        'auto start/end recording
        If DateTimePicker1.Value.ToString("HH:mm") = "00:00" And DateTimePicker2.Value.ToString("HH:mm") = "00:00" Then Exit Sub

        If DateTimePicker1.Value.ToString("HH:mm") = DateTime.Now.ToString("HH:mm") And Button2.Text = "REC" Then
            Me.TopMost = True
            Call Button2_Click(Nothing, Nothing)            'start recording
            Me.TopMost = False
        End If

        If DateTimePicker2.Value.ToString("HH:mm") = DateTime.Now.ToString("HH:mm") And Button2.Text = "STOP" Then
            Me.TopMost = True
            Call Button2_Click(Nothing, Nothing)            'end recording
            Me.TopMost = False
        End If

    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If Button2.Text = "STOP" Then
            MsgBox("Please stop the recording and try agian!")
            e.Cancel = True
        Else
            '##############################################< Close all programs/windows/processes after closing >##############################################
            Dim ListOfProcesses1() As System.Diagnostics.Process = System.Diagnostics.Process.GetProcessesByName("ffmpeg")
            For Each Process As System.Diagnostics.Process In ListOfProcesses1
                Process.Kill()
            Next

            Dim ListOfProcesses2() As System.Diagnostics.Process = System.Diagnostics.Process.GetProcessesByName("yt-dlp")
            For Each Process As System.Diagnostics.Process In ListOfProcesses2
                Process.Kill()
            Next

            Dim ListOfProcesses3() As System.Diagnostics.Process = System.Diagnostics.Process.GetProcessesByName("cmd")
            For Each Process As System.Diagnostics.Process In ListOfProcesses3
                Process.Kill()
            Next

            Call DeleteThumbnail()  'delete all thumbnails in program folder
        End If

        '----------- Change options file --------------------
        Dim Lines() As String = System.IO.File.ReadAllLines(Application.StartupPath & "\YSRec_options.ini")
        Lines(0) = TextBox2.Text
        Lines(1) = ComboBox1.SelectedIndex
        System.IO.File.WriteAllLines(Application.StartupPath & "\YSRec_options.ini", Lines)

    End Sub

    Private Sub Button3_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button3.Click
        '##############################################<  Open file output folder >##############################################
        TextBox2.BringToFront()
        TextBox2.Refresh()

        '----------- Choose output folder --------------------
        If (FolderBrowserDialog1.ShowDialog() = DialogResult.OK) Then
            TextBox2.Text = (FolderBrowserDialog1.SelectedPath & "\").Replace("\\", "\")
        Else
            TextBox1.BringToFront()
            TextBox1.Refresh()
        End If

        TextBox1.BringToFront()
        TextBox1.Refresh()
    End Sub

    Private Sub Label4_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Label4.Click
        DateTimePicker1.Value = Date.FromOADate(0)            'set timer to zero
        DateTimePicker2.Value = Date.FromOADate(0)
    End Sub

    Private Sub Label5_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Label5.Click
        DateTimePicker1.Value = Date.FromOADate(0)            'set timer to zero
        DateTimePicker2.Value = Date.FromOADate(0)
    End Sub

End Class
